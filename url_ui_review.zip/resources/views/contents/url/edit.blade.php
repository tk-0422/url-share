<x-app-layout>
<x-slot name="header">
    <x-header title="URl編集" />
</x-slot>

<div class="p-editUrl p-formPage">
    <div class="c-card">
<form method="POST" action="{{route('contents.url.update',['content'=>$content->id,'url'=>$url->id])}}">
    @csrf
    @method('PUT')
    <div class="c-form-group">
    <label class="c-form-label">タイトル</label>
    <input type="text" name="title" value="{{old('title',$url->title)}}" class="c-form-input"><!-- oldで前回の文字を保持-->
    </div>

    <div class="c-form-group">
    <label class="c-form-label">URL</label>
    <input type="url" name="url" value="{{old('url',$url->url)}}" class="c-form-input">
    </div>


    <div class="c-card__actions">
    <button type="submit" class="c-button is-submit">更新する</button>
    <a href="{{route('contents.url.index',['content' => $content->id])}}" class="c-button is-gray">URL一覧へ</a>
    </div>
    
</form>
</div>
</div>
</x-app-layout>