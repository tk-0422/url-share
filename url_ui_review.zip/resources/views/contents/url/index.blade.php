<x-app-layout>
<x-slot name="header">
 <x-header title="URL一覧" />
</x-slot>

<!-- コンテンツ詳細表示 -->
  <div class="p-url-meta">
    <h2 class="p-urlIndex__title">コンテンツ名: {{ $content->title }}</h2>
    <p class="c-card__body">
      <span class="c-label">説明:</span>{{ $content->description }}
    </p>
  </div>

@if ($urls->isEmpty())
     <div class="c-card">
      <p>投稿したURLはありません。</p>
       <div class="c-button-group is-right">
          <a href="{{ route('contents.url.create', $content) }}" class="c-button is-green">URLを投稿する</a>
          <a href="{{ route('contents.index') }}" class="c-button is-gray">コンテンツ一覧へ</a>
        </div>
     </div>  
    @else

 <div class="p-url-index p-listGrid">
  @foreach($urls as $url)
    <div class="c-card">
      <h4 class="c-card__title">{{ $url->title }}</h4>
      <p class="c-card__body"><a href="{{$url->url}}">{{ $url->url }}</a></p>

 <!--コンテンツの編集、削除ボタン　-->
  <div class="c-card__actions">
    <a class="c-button" href="{{ route('contents.url.edit',['content'=> $content->id,'url' =>$url->id]) }}">編集</a>
      <form method="POST" action="{{route('contents.url.destroy',['content'=>$content->id,'url'=>$url->id])}}">
        @csrf
        @method("DELETE")
        <button  class="c-button is-red" type="submit" onclick="return confirm('本当に削除しますか？')">削除</button>
      </form>
  </div>
 </div>
      @endforeach
  </div>


<div class="c-card__action">
  <div class="c-button-group is-left">
    <a href="{{ route('contents.url.create',['content'=>$content->id])}}" class="c-button is-gray">
     URL投稿
    </a>

    <a href="{{ route('contents.index') }}" class="c-button is-gray">
    コンテンツ一覧
    </a>

    <a href="{{ route('invite.form',['content'=>$content->id]) }}" class="c-button is-gray">
    友達招待
    </a>

  </div>
</div>
@endif
</x-app-layout>


