<x-app-layout>
    <x-slot name="header">
        <x-header title="コンテンツ一覧" />
    </x-slot>

    <section>

       <h3 class="p-contentsIndex__title">作成したコンテンツ</h3>
    @if ($myContents->isEmpty())
        <p>作成したコンテンツはありません。</p>
    @else

        <div class="p-contents-index p-listGrid">
            @foreach($myContents as $content)
            <div class="c-card">
                <h3 class="p-contents-index__title">{{ $content->title }}</h3>
                <p class="c-card__body">{{ $content->description }}</p>

              <div class="c-button-group">
                <!--コンテンツの編集ボタン-->
                <a href="{{ route('contents.edit',$content->id) }}" class="c-button">編集</a>
                <!--削除ボタン-->
                <form method="POST" action="{{route('contents.destroy',$content->id)}}">
                @csrf
                @method("DELETE")
                <button type="submit" onclick="return confirm('本当に削除しますか？')"  class="c-button is-red">削除</button>
                </form>
                <a href="{{ route('contents.url.index', ['content' => $content->id]) }}"  class="c-button is-green">URL一覧へ</a>
              </div>
            </div>
                @endforeach
    @endif
    </section>

    <section>
    <h3 class="p-contentsIndex__title">招待されたページ一覧</h3>
    @if ($inviteContents->isEmpty())
        <p>招待されたコンテンツはありません</p>
    @else

    <div class="p-contents-index">
    <div class="c-card">
            @foreach($inviteContents as $content)
                <h3 class="p-contents__title">{{ $content->title }}</h3>
                <p class="c-card__body">{{ $content->description }}</p>
                <a href="{{route('contents.url.index',['content'=>$content->id])}}" class="c-button is-green">URL一覧へ</a>
            @endforeach
    </div>
    @endif
    </div>
    </div>
    </section>
</x-app-layout>

