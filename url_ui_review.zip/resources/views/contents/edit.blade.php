<x-app-layout>

<x-slot name="header">
    <x-header title="コンテンツ編集" />
</x-slot>

<div class="p-editContent p-formPage">
 <div class="c-card">
<form method="POST" action="{{route('contents.update',$content->id)}}" class="c-form">
    @csrf
    @method('PUT')
    <div class="c-form-group">
    <label for="title" class="c-form-label">タイトル</label>
    <input type="text" name="title" value="{{old('title',$content->title)}}" class="c-form-input">
    </div>

    <div class="c-form-group">
    <label for="title" class="c-form-label">説明</label>
    <textarea name="description" class="c-form-input">{{old('description',$content->description)}}</textarea>
    </div>
    
    <div class="c-card__actions">
    <button type="submit" class="c-button is-submit">更新する</button>
    <a href="{{route('contents.index')}}" class="c-button is-gray">コンテンツ一覧へ</a>
    </div>
</form>

 </div>
</div>
</x-app-layout>