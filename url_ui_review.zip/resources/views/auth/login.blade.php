<x-app-layout>
    <x-slot name="header">
        <x-header title="ログイン画面"
          :customButton="['url' =>route('register'),'label'=>'新規作成']" />
    </x-slot>

  <div class="p-login p-formPage">
    <div class="c-card">
      <h2 >ログイン</h2>

      @if (session('status'))
        <div class="c-message">
          {{ session('status') }}
        </div>
      @endif

      <form method="POST" action="{{ route('login') }}" class="c-form">
        @csrf
        <div class="c-form-group">
          <label for="email" class="c-form-label">メールアドレス</label>
          <input id="email" type="email" name="email" class="c-form-input"
           value="{{old('email')}}" required autofocus autocomplete="username">
           <x-input-error :messages="$errors->get('email')" />
        </div>

        <div class="c-form-group">
          <label for="password" class="c-form-label">パスワード</label>
          <input id="password" type="password" name="password" class="c-form-input" required autocomplete="password">
          <x-input-error :messages="$errors->get('password')" />
        </div>

        <div class="c-card__actions">
          <button type="submit" class="c-button">ログイン</button>
        </div>
      </form>
    </div>
  </div>
</x-app-layout>