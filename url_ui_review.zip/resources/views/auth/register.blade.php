<x-app-layout>
    <x-slot name="header">
        <x-header title="アカウント作成"
          :customButton="['url' =>route('login'),'label'=>'ログイン画面']" />
    </x-slot>

    <div class="p-register p-formPage">
     <div class="c-card">
            <h2>新規作成</h2>
    <form method="POST" action="{{ route('register') }}" class="c-form">
        @csrf

        <!-- Name -->
        <div class="c-form-group">
            <x-input-label for="name" :value="__('Name')" class="p-register-users__title" />
            <x-text-input id="name" class="c-form-input" type="text" name="name" :value="old('name')" required autofocus autocomplete="name" />
            <x-input-error :messages="$errors->get('name')"  />
        </div>

        <!-- Email Address -->
        <div class="c-form-group">
            <x-input-label for="email" :value="__('Email')" class="p-register-users__title" />
            <x-text-input id="email" class="c-form-input" type="email" name="email" :value="old('email')" required autocomplete="username" />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>

        <!-- Password -->
        <div class="c-form-group">
            <x-input-label for="password" :value="__('Password')" class="p-register-users__title" />

            <x-text-input id="password" class="c-form-input"
                            type="password"
                            name="password"
                            required autocomplete="new-password" />

            <x-input-error :messages="$errors->get('password')" class="mt-2" />
        </div>

        <!-- Confirm Password -->
        <div class="c-form-group">
            <x-input-label for="password_confirmation" :value="__('Confirm Password')" class="p-register-users__title" />

            <x-text-input id="password_confirmation" class="c-form-input"
                            type="password"
                            name="password_confirmation" required autocomplete="new-password" />

            <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
        </div>

            <x-primary-button class="c-button">
                {{ __('Register') }}
            </x-primary-button>
    </form>
     </div>
    </div>
</x-app-layout>