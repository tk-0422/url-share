<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="l-body">
     <div class="l-wrapper">

            <!-- Page Heading -->
            @isset($header)
                        {{ $header }}
            @endisset

            <!-- Page Content -->

            <main class="l-main">
                <div class="c-alerts">
                    @if (session('status'))
                        <div class="c-alert is-success">{{ session('status') }}</div>
                    @endif

                    @if (session('message'))
                        <div class="c-alert is-success">{{ session('message') }}</div>
                    @endif

                    @if (session('error'))
                        <div class="c-alert is-error">{{ session('error') }}</div>
                    @endif

                    {{-- バリデーションエラー（複数） --}}
                    @if ($errors->any())
                        <div class="c-alert is-error">
                        <ul style="margin:0; padding-left:1rem;">
                            @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        </div>
                    @endif
                </div>
                {{ $slot }}
            </main>

            <footer class="l-footer">
                 &copy; {{ date('Y') }} MyApp. All rights reserved.
            </footer>

        
     </div>
    </body>
</html>
