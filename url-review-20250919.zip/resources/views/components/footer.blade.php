<footer class="l-footer">
    <div class="l-footer__inner">&copy; {{ date("Y") }} MyApp. All rights reserved.</div>
</footer>
